fetch('http://localhost:6606/encrypt-password', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
        password: '',
        modulus: '',
        exponent: '',
    }),
});